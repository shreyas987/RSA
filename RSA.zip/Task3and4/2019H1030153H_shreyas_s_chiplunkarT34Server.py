# first of all import the socket library 
import socket	
import hashlib
import thread


#Task 3. Implement a client-server program which will facilitate a client to register itself to the server. Essentially, a server should #	keep a table of user-hash(password) entry for each user.  Use any cryptographic hash in any of the Python library.

#Task 4. Every registered client must declare its public key to the server during registration phase. Server should maintain a table of #	public key. Any registered client can request separately the public key of any other registered client and the server will supply #	the corresponding public key.  Request of public key can be made several times.

#----------RUN in same order --> COMMAND --> python 2019H1030153H_shreyas_s_chiplunkarT34Server.py
#					     python 2019H1030153H_shreyas_s_chiplunkarT34Client.py


#---------------------------------------------------------------------
# thread function 
def threaded(c): 
	# Option 1 : Verify or add user
	# Option 2 : Request Public Key 
	
	op = c.recv(1024).decode('utf-8')
	while True:
		if op == "1":
			print("Provide username and password")
			usr = c.recv(1024).decode('utf-8')
			print("username received")
			pw = c.recv(1024).decode('utf-8')
			print("password received")
			h = c.recv(1024).decode('utf-8')
			
			e = c.recv(1024).decode('utf-8')
			
			flag =0
			try:
				f= open("config.txt","r")
				contents = f.read()
			finally:
				f.close()
			if usr in contents:
				m = hashlib.sha256(pw)
				if m.hexdigest().encode('utf-8') == h: 
					if m.hexdigest().encode('utf-8') in contents:
						flag =1
			else:
				#f.close()
				try:
					f1 = open("config.txt","a+")
					f1.write("\n")
					f1.write(usr+" "+h+" "+"Key="+e+";")
				finally:
					f1.close()
				flag = 2
			#f.close()
			if flag == 0:
				print ("User not present or invalid password ")
				c.send("User not present or invalid password ")
			elif (flag == 1):
				print("user verified ")	
				c.send("user verified ")
			elif flag ==2:
				print("user added to database ")
				c.send("user added to database ")
			c.close()
			break
		elif op == "2":
			print("Provide username")
			usr = c.recv(1024)
			print("username received")
			f = open("config.txt","r")
			contents = f.read()
			f.close()
			if usr in contents:
				st = contents.find('Key',contents.find(usr))
				ed = contents.find(';',contents.find(usr))
				c.send(str(contents[st:ed]))
			else:
				c.send('User not present. Add user to generate the key')
			c.close()
			break
		else:
			print("TRY AGAIN")
			break

		
#---------------------------------------------------------------------
#MAIN 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)		 
print ("Socket successfully created")
s.setsockopt( socket.SOL_SOCKET, socket.SO_REUSEADDR , 1)
s.setblocking(0)
s.settimeout(30)
#Any port number
port = 1234				

s.bind(('', port))		 
print ("socket binded to %s" %(port)) 

# socket into listening mode 
s.listen(20)	 
print ("socket is listening")

while True: 
	
	# Establish connection with client. 
	c, (ip,port) = s.accept()	 
	print ('Got connection from', str(ip) + str(port))
	#t1 = thread.start_new_thread(threaded, (c,)) 
	threaded(c)
	
s.shutdown(1)
s.close()
		
		
