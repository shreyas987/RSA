import socket                  
import hashlib
import random


#Task 3. Implement a client-server program which will facilitate a client to register itself to the server. Essentially, a server should #	keep a table of user-hash(password) entry for each user.  Use any cryptographic hash in any of the Python library.

#Task 4. Every registered client must declare its public key to the server during registration phase. Server should maintain a table of #	public key. Any registered client can request separately the public key of any other registered client and the server will supply #	the corresponding public key.  Request of public key can be made several times.

#----------RUN in same order --> COMMAND --> python 2019H1030153H_shreyas_s_chiplunkarT34Server.py
#					     python 2019H1030153H_shreyas_s_chiplunkarT34Client.py


#---------------------------------------------------------------------
def gcd(a,b): 
	if b==0: 
		return a 
	else: 
		return gcd(b,a%b) 
#---------------------------------------------------------------------
#MAIN

s = socket.socket()             
host = ''     			
port = 1234                    
	
s.connect((host, port))
# Option 1 : Add or verify user
# Option 2 : Request for public Key

op = raw_input('Enter 1 \n To verify user or Add new user \nEnter 2 \n For requesting for public key of a user \n')
s.sendall(str.encode(str(op)))
if int(op) == 1:
	usr = ''
	pw = ''
	usr = raw_input('Enter the value of usename = ')
	s.send(usr)
	pw = raw_input('Enter the value of password = ')
	s.send(pw)
	
	m = hashlib.sha256(pw)
	s.send(str.encode(str(m.hexdigest())))
	
	#Public key
	p = 7
	q = 23
	ph = (p-1)*(q-1)
	count=0
	while count<100:
		e = random.choice([2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109])
		r = gcd(e,ph)
		if r == 1:
			break
		else:
			count=count+1

	
	
	#s.sendall(str.encode(str(op)))
		
	
	s.send(str.encode(str(e)))
	
	print(s.recv(1024))

	s.shutdown(1)
	s.close()
elif int(op) == 2:
	usr = raw_input('Enter the user whose public is needed \n')
	#s.send(str.encode(str(op)))
	s.send(str.encode(str(usr)))
	print('__Public key__ ')
	print(s.recv(1024))
	s.shutdown(1)
	s.close()

