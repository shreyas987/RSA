---Task1 and Task2 are coded  into a single program
	
	1. Go to folder 'Task1and2'
	2. Open terminal in this folder
	3. Run command $ python 2019H1030153H_shreyas_s_chiplunkarT12.py

---Task3 and Task4 are coded together

	1. Go to folder 'Task3and4'. Config.txt contains the user details,hashed password and the key value
	2. Open 2 terminals in this folder
	3. Run command $ python 2019H1030153H_shreyas_s_chiplunkarT34Server.py    (in one terminal)
			 python 2019H1030153H_shreyas_s_chiplunkarT34Client.py    (in another terminal)
	
	New users can be added through program
	currently some available users are
	- USERNAME	PASSWORD
	  usr1    	pass1
	  usr2    	pass2
	  usr3   	pass3
	  usr4   	pass4
	  usr5   	pass5

---Task5
	1. Go to folder 'Task5'. Config.txt contains the user details,hashed password and the key value.
	2. Open 3 terminals in this folder
	3. Run following command in 3 different terminals. Run the server first followed by clients: 
			Terminal 1 -->python 2019H1030153H_shreyas_s_chiplunkarT5Server.py
			Terminal 2 -->python 2019H1030153H_shreyas_s_chiplunkarT5Client.py
			Terminal 3 -->python 2019H1030153H_shreyas_s_chiplunkarT5Client.py
	
	currently some available users are. New users cannot be added in this code.
	- USERNAME	PASSWORD
	  usr1    	pass1
	  usr2    	pass2
	  usr3   	pass3
	  usr4   	pass4
	  usr5   	pass5
