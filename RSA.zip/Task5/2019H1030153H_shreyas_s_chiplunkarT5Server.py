import socket	
import hashlib
import math
from decimal import Decimal

#Task 5. Two registered clients will execute the Secure Two Party Computation two decide who is richer without revealing its wealth to any #	one. The clients will communicate via the server.

#Command Run in same order : Terminal 1 -->python 2019H1030153H_shreyas_s_chiplunkarT5Server.py
#			    Terminal 2 -->python 2019H1030153H_shreyas_s_chiplunkarT5Client.py
#			    Terminal 3 -->python 2019H1030153H_shreyas_s_chiplunkarT5Client.py

# RUN 2 client programs in 2 different terminals and 1 Server

#-------------------------------------------------------------------
#GCD
def gcd(a,b): 
	if b==0: 
		return a 
	else: 
		return gcd(b,a%b) 
#-------------------------------------------------------------------		
#encryption
def encryption(m,e):
	ctt = Decimal(0) 
	ctt =pow(m,e) 
	ct = ctt % n 
	return ct
#-------------------------------------------------------------------	
#decryption
def decryption(ct,d):
	dtt = Decimal(0) 
	dtt = pow(ct,d) 
	dt = dtt % n 
	return dt
#-------------------------------------------------------------------
def isPrime(n) : 
  
    # Corner cases 
    if (n <= 1) : 
        return False
    if (n <= 3) : 
        return True
  
    if (n % 2 == 0 or n % 3 == 0) : 
        return False
  
    i = 5
    while(i * i <= n) : 
        if (n % i == 0 or n % (i + 2) == 0) : 
            return False
        i = i + 6
  
    return True	
#-------------------------------------------------------------------    
#Compute Zi's
def Zi(m,p):
	return m%p
#-------------------------------------------------------------------	
def check(Z2,P):
	flag=0
	for i in range(100):
		for j in range(100):
			if i!=j:
				if abs(Z2[i]-Z2[j])>=2:
					flag=1
				else:
					return 0
	return flag
#-------------------------------------------------------------------
def func():
	M1 = 39
	P = 31
	#Alice
	
	C = encryption(M1,e)
	C1 = C-x
	M1b = bin(abs(M1))
	print('C1 = '+str(C1))

	#Bob
	M2 = []
	#print('___M2___value')
	for i in range(100):
		M2.append(decryption(C1+i+1,d))
	#	print (M2[i])

	fl = 0
	v = 0
	Z2 = []
	while fl==0:
		
		for i in range(100):
			Z2.append(Zi(M2[i],P))
		fl=1
		#fl = check(Z2,P)
					
	#print ('__P__value = '+str(P))
	#print ('___Z2___value')
	for i in range(100):
		if i>=y:
			Z2[i]+=1
	#	print (Z2[i])
		

	#Alice receives Z2
	# check the xth value
	r1 = Z2[x-1]%P
	r2 = M1%P
	print ('Result is...')
	if r1!=r2:
		print('client 1 > client 2')
		c1.send('You are richer')
		c2.send('You are not richer')
	else:
		print('client 2 > client 1')
		c1.send('You are not richer')
		c2.send('You are richer')
	c1.close()
	c2.close()
#-------------------------------------------------------------------	
# thread function 
def threaded(c): 
	# Verify or add user
	
	print("Provide username and password")
	usr = c.recv(1024).decode('utf-8')
	print("username received")
	pw = c.recv(1024).decode('utf-8')
	print("password received")
	h = c.recv(1024).decode('utf-8')
	
	flag =0
	try:
		f= open("config.txt","r")
		contents = f.read()
	finally:
		f.close()
	if usr in contents:
		m = hashlib.sha256(pw)
		if m.hexdigest().encode('utf-8') == h: 
			if m.hexdigest().encode('utf-8') in contents:
				flag =1
	#f.close()
	if flag == 0:
		print ("User not present or invalid password ")
		#c.send("User not present or invalid password ")
	elif (flag == 1):
		print("user verified ")	
		#c.send("user verified ")

	#c.close()
	return flag


#-------------------------------------------------------------------------------------------------
#MAIN
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)		 
print "Socket successfully created. IT HAS A TIMEOUT OF 30 SECS"
s.setsockopt( socket.SOL_SOCKET, socket.SO_REUSEADDR , 1)
s.settimeout(30)
#Any port number
port = 12345				
x = -1
y = -1
#__RSA__Values are Set
p = 7
q = 23
n = p*q
t = (p-1)*(q-1)

#encryption key e
for e in range(2,t): 
	if gcd(e,t)== 1: 
		break
		
#decryption key d
for d in range(0,t): 
	if (d*e)%t == 1: 
		break

s.bind(('', port))		 
print "socket binded to %s" %(port) 

# put the socket into listening mode 
s.listen(5)	 
print "socket is listening"

count = 0
# Allows exactly 2 connections
while count<2: 
	fl = 0
	if count == 0:
		# Establish connection with client. 
		c1, (ip1,port1) = s.accept()	 
		print ('Got connection from', str(ip1) + str(port1))
		fl = threaded(c1)
		c1.send(str.encode(str(fl)))
		if fl == 1:
			count=count+1
			x = int(c1.recv(1024))
		else:
			c1.close()
	elif count == 1:
		# Establish connection with client. 
		c2, (ip2,port2) = s.accept()	 
		print ('Got connection from', str(ip2) + str(port2))
		fl = threaded(c2)
		c2.send(str.encode(str(fl)))
		if fl == 1:
			count=count+1
			y = int(c2.recv(1024))	
		else:
			c2.close()
	
	if count == 2:
		func()
	
s.shutdown(1)
s.close()
