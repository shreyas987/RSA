import socket                 
import hashlib
import random


#Task 5. Two registered clients will execute the Secure Two Party Computation two decide who is richer without revealing its wealth to any #	one. The clients will communicate via the server.

#Command Run in same order :Terminal 1 -->python 2019H1030153H_shreyas_s_chiplunkarT5Server.py
#			    Terminal 2 -->python 2019H1030153H_shreyas_s_chiplunkarT5Client.py
#			    Terminal 3 -->python 2019H1030153H_shreyas_s_chiplunkarT5Client.py

# RUN 2 client programs in 2 different terminals and 1 Server


s = socket.socket()             
host = ''     			
port = 12345                    
	
s.connect((host, port))

usr = raw_input('Enter the value of usename = ')
s.send(usr)
pw = raw_input('Enter the value of password = ')
s.send(pw)
m = hashlib.sha256(pw)
s.send(str.encode(str(m.hexdigest())))

op = s.recv(1024)
if op == "1":
	val = raw_input('Enter your asset value between 1 and 100 ')
	s.send(str.encode(str(val)))
	print(s.recv(1024))
else:
	print("Invalid User")

s.shutdown(1)
s.close()

