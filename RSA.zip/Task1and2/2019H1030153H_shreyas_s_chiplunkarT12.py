from decimal import Decimal 
import random


#-----------------Task 1. Implement RSA in your own code. Do not use any library for this work.
#-----------------Task 2. Implement the protocol "secure two party computation" provided in the attached file. For any clarification, #-----------------	either contact me or please look at online material which must not be significantly different from what is provided #-----------------	in the file. 
#-----------------command --> python 2019H1030153H_shreyas_s_chiplunkarT12.py


#---------------------------------------------------------------------
#GCD
def gcd(a,b): 
	if b==0: 
		return a 
	else: 
		return gcd(b,a%b) 
#---------------------------------------------------------------------		
#encryption
def encryption(m,e):
	ctt = Decimal(0) 
	ctt =pow(m,e) 
	ct = ctt % n 
	#print('Encrypted msg '+str(ct))
	return ct
#---------------------------------------------------------------------	
#decryption
def decryption(ct,d):
	dtt = Decimal(0) 
	dtt = pow(ct,d) 
	dt = dtt % n 
	#print('Decrypted msg '+str(dt))
	return dt
#---------------------------------------------------------------------
def isPrime(n) : 
  
    # Corner cases 
    if (n <= 1) : 
        return False
    if (n <= 3) : 
        return True
  
    if (n % 2 == 0 or n % 3 == 0) : 
        return False
  
    i = 5
    while(i * i <= n) : 
        if (n % i == 0 or n % (i + 2) == 0) : 
            return False
        i = i + 6
  
    return True	
#---------------------------------------------------------------------  
#Compute Zi's
def Zi(m,p):
	return m%p
#---------------------------------------------------------------------	
def check(Z2,P):
	flag=0
	for i in range(100):
		for j in range(100):
			if i!=j:
				if abs(Z2[i]-Z2[j])>=2:
					flag=1
				else:
					return 0
	return flag
#---------------------------------------------------------------------
#MAIN - RSA
print('___RSA___')
p = int(input('Enter prime value of p = ')) 
q = int(input('Enter prime value of q = ')) 
m = int(input('Enter the value of message = ')) 
n = p*q 
t = (p-1)*(q-1) 

#encryption key e
for e in range(2,t): 
	if gcd(e,t)== 1: 
		break

#Decryption key d
for d in range(0,t): 
	if (d*e)%t == 1: 
		break

#encryption		
ct = encryption(m,e)
print('Encrypted msg '+str(ct))
#decryption
dt = decryption(ct,d)
print('Decrypted msg '+str(dt))


#-----------------------------------Yao' millionaire problem------------------------------------------
print('\n')
print('___Yao Millionaire problem___ ')
#M1 = 39
#P = 31
x = int(input('Enter value of x between 1 and 100 '))
y = int(input('Enter value of y between 1 and 100 '))
M1 = int(input('Enter random value for M1 '))
#Alice

print('M1 = '+str(M1))
C = encryption(M1,e)
C1 = C-x
M1b = bin(abs(M1))
print('C1 = '+str(C1))



#Bob
M2 = []
print('___M2___value')
for i in range(100):
	M2.append(decryption(C1+i+1,d))
	print (M2[i])

fl = 0
v = 0
Z2 = []
while fl==0:

	while True:
		P = random.randrange(1,M1)
		if isPrime(P):
			break
	
	for i in range(100):
		Z2.append(Zi(M2[i],P))
	fl=1
	#fl = check(Z2,P)
				
print ('__P__value = '+str(P))
print ('___Z2___value')
for i in range(100):
	if i>=y:
		Z2[i]+=1
	print (Z2[i])
	

#Alice receives Z2
# check the xth value
r1 = Z2[x-1]%P
r2 = M1%P
print ('Result is...')
if r1!=r2:
	print('x > y')
else:
	print('y > x')
